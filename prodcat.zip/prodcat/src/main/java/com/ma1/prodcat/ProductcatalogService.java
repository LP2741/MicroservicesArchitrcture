package com.ma1.prodcat;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductcatalogService {

    private static final Logger logger = LoggerFactory.getLogger(ProductcatalogService.class);
    private  final ProductcatalogRepository prodCatRepository;

    public ProductcatalogService(ProductcatalogRepository prodCatRepository) {
        this.prodCatRepository = prodCatRepository;
    }

    public void createProduct(ProductRequest productRequest) {
        logger.info("Product Catalog  service started with name:", productRequest.getName());
        Product product = Product.builder()
                .name(productRequest.getName())
                .description(productRequest.getDescription())
                .price(productRequest.getPrice())
                .build();
        prodCatRepository.save(product);
        logger.info("Product Catalog service saved with id:", product.getId());
    }

    @Transactional(readOnly = true)
    public ProductResponse getProductById(String id) {
        Product product = prodCatRepository.findById(id)
                .orElseThrow(() -> {
                    return new RuntimeException("Product not found with id: " + id);
                });
        return mapToResponse(product);
    }

    private ProductResponse mapToResponse(Product product) {
        return new ProductResponse(
                product.getId(),
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getStock()
        );
    }


}
