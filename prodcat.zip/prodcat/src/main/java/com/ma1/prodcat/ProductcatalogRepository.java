package com.ma1.prodcat;

import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;
public interface ProductcatalogRepository extends MongoRepository<Product, String>{


}
