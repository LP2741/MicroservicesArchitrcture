package com.ma1.prodcat;


import lombok.*;

import java.math.BigDecimal;


@Getter
@Setter
public class ProductRequest {

    private String name;
    private String description;
    private BigDecimal price;
    private int stock;

}
