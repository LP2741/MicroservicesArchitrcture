package com.ma1.prodcat;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class ProductcatalogController {
    private static final Logger logger = LoggerFactory.getLogger(ProductcatalogController.class);
    @Autowired
    private ProductcatalogService prodCatService;

    /* This method is generated for my testing purpose*/
    @GetMapping("/product")
    public String hello(HttpServletRequest httpRequest) {//Dependency Injection.Method Injection
        String userAgent = httpRequest.getHeader("User-Agent");
        return "Hello Lakshmi" + userAgent;
    }

    /*This method is generated to create products*/
    @PostMapping("create/products")
    public ResponseEntity<String> createProduct(@RequestBody ProductRequest prodRequest) {
        logger.info("Product Catalog  service started with name print :", prodRequest.getName());
        prodCatService.createProduct(prodRequest);
        return ResponseEntity.ok("Product created successfully with Name: " + prodRequest.getName());
    }


    @GetMapping("id/{id}")
    public ResponseEntity<ProductResponse> getProductById(@PathVariable String id) {
        try {
            ProductResponse productResponse = prodCatService.getProductById(id);
            return ResponseEntity.ok(productResponse);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    /*  @GetMapping("/checkstock/{id}")
      public boolean checkStock(@PathVariable String id) {
          logger.info("id :", id);
          ProductResponse product = prodCatService.getProductById(id);
          logger.info("product.getStock()  :", product.getStock() );
          return product != null && product.getStock() > 0;
      }*/
    @GetMapping("/checkstock/{id}/{quantity}")
    public boolean checkStock(@PathVariable String id, @PathVariable int quantity) {
        ProductResponse product = prodCatService.getProductById(id);
        return product != null && product.getStock() >= quantity;
    }

    @PostMapping("/deductstock/{id}/{quantity}")
    public ResponseEntity<?> deductStock(@PathVariable String id, @PathVariable int quantity) {
        try {
            prodCatService.deductStock(id, quantity);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }


    @GetMapping("/{id}/{stock}")
    public ResponseEntity<String> getProductById(@PathVariable String id, @PathVariable int stock) {
        try {
            ProductResponse productResponse = prodCatService.getProductById(id);

            if (productResponse.getStock() >= stock) {
                return ResponseEntity.ok("Product is available with enough stock.");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Insufficient stock. Available: " + productResponse.getStock());
            }
            // return ResponseEntity.ok(productResponse);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }


    @PutMapping("/update")
    public ResponseEntity<String> updateProduct(@RequestBody Map<String, Object> data) {
        String id = data.get("id").toString();
        int stock = Integer.parseInt(data.get("stock").toString());

        prodCatService.updateStock(id, stock); // ✅ call service method instead of doing it here

        return ResponseEntity.ok("Product updated");
    }

}
