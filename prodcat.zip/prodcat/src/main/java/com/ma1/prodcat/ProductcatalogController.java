package com.ma1.prodcat;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("api/v1")
public class ProductcatalogController {
    private static final Logger logger = LoggerFactory.getLogger(ProductcatalogController.class);
    @Autowired
    private ProductcatalogService prodCatService;

    @GetMapping("/product")
    public String hello(HttpServletRequest httpRequest){//Dependency Injection.Method Injection
        String userAgent = httpRequest.getHeader("User-Agent");
        return "Hello Lakshmi"+userAgent;
    }

    @PostMapping("create/products")
    public ResponseEntity<String> createProduct(@RequestBody ProductRequest prodRequest)
    {
        logger.info("Product Catalog  service started with name print :", prodRequest.getName());
        prodCatService.createProduct(prodRequest);
        return ResponseEntity.ok("Product created successfully with Name: " + prodRequest.getName());
    }


    @GetMapping("id/{id}")
    public ResponseEntity<ProductResponse> getProductById(@PathVariable String id) {
        try {
            ProductResponse productResponse = prodCatService.getProductById(id);
            return ResponseEntity.ok(productResponse);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }


}
