package com.ma1.prodcat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdcatApplicationTests {

    @Test
    void contextLoads() {
    }

}
