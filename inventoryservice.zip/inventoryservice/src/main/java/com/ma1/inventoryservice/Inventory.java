package com.ma1.inventoryservice;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


import org.springframework.data.annotation.Id;

import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@Builder
@Document(collection = "product")
public class Inventory {

    @Id
    private String id;
    private String productId;
    private int stock;
}
