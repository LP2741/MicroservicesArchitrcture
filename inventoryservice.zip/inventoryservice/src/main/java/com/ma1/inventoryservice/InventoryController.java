package com.ma1.inventoryservice;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;


@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    private static final Logger logger = LoggerFactory.getLogger(InventoryController.class);


    private final ProductClient productClient;
    private final InventoryService inventoryService;

    public InventoryController(ProductClient productClient,InventoryService inventoryService) {
        this.inventoryService = inventoryService;
        this.productClient = productClient;
    }
    @PostMapping("/create")
    public Inventory create(@RequestBody Inventory inventory) {
        return inventoryService.pay(inventory);
    }


    @GetMapping("/stockcheck/{id}/{stock}")
    public String checkProdAndReserve(@PathVariable String id,@PathVariable int stock) {
        logger.info("Prod call back started:", id,stock);
        return productClient.callProdService(id,stock);
    }

    @PostMapping("/reserve")
    public ResponseEntity<String> reserveStock(@RequestBody InventoryRequest request) {
        logger.info("reserveStock:", request.getId(),request.getStock());
        boolean success = inventoryService.reserveStock(request.getId(), request.getStock());

        if (success) {
            return ResponseEntity.ok("Stock reserved.");
        } else {
            return ResponseEntity.badRequest().body("Insufficient stock or product not found.");
        }
    }



}
