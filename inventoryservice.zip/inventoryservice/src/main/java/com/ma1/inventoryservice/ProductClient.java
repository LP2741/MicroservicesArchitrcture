package com.ma1.inventoryservice;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.web.client.RestTemplate;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashMap;
import java.util.Map;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.http.HttpStatus;

@Service
public class ProductClient {

    private static final Logger logger = LoggerFactory.getLogger(ProductClient.class);

    private final RestTemplate restTemplate;

    public ProductClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @CircuitBreaker(name = "prodcat", fallbackMethod = "fallbackProd")
    public String callProdService(String id, int stock) {
        try {
            String url = "http://localhost:9191/prodcat/api/v1/" + id + "/" + stock;
            logger.info("Product call back started: {}", url);

            String productResponse = restTemplate.getForObject(url, String.class);
// Case 1: Product not found in response
            if (productResponse == null || productResponse.toLowerCase().contains("not found")) {
                logger.info("Product not found, creating new one with stock {}", stock);

                String createUrl = "http://localhost:9191/prodcat/api/v1/create/products";
                Map<String, Object> createPayload = new HashMap<>();
                createPayload.put("id", id);
                createPayload.put("stock", stock);

                restTemplate.postForObject(createUrl, createPayload, String.class);
                return "Product not found — created with stock " + stock;
            }

            // Case 2: Product exists — try parsing stock
            try {
                int currentStock = Integer.parseInt(productResponse.trim());
                if (currentStock < stock) {
                    logger.info("Insufficient stock. Updating to {}", stock);

                    String updateUrl = "http://localhost:9191/prodcat/api/v1/update";
                    Map<String, Object> updatePayload = new HashMap<>();
                    updatePayload.put("id", id);
                    updatePayload.put("stock", stock);

                    restTemplate.put(updateUrl, updatePayload);
                    return "Product existed but stock was low — updated to " + stock;
                }
            } catch (NumberFormatException nfex) {
                logger.warn("Could not parse stock. Response: {}", productResponse);
                // Optional: Treat this as non-critical and continue or fallback
            }

        } catch (HttpClientErrorException e) {
            HttpStatus statusCode = HttpStatus.valueOf(e.getRawStatusCode()); // safe fallback
            String responseBody = e.getResponseBodyAsString();

            // Case 3: Product not found — create it
            if (statusCode == HttpStatus.NOT_FOUND) {
                logger.warn("Product not found (404), creating with stock {}", stock);

                String createUrl = "http://localhost:9191/prodcat/api/v1/create/products";
                Map<String, Object> createPayload = new HashMap<>();
                createPayload.put("id", id);
                createPayload.put("stock", stock);

                restTemplate.postForObject(createUrl, createPayload, String.class);
                return "Product not found — created with stock " + stock;
            }

            // Case 4: Stock insufficient message
            if (statusCode == HttpStatus.BAD_REQUEST && responseBody.contains("Insufficient stock")) {
                logger.info("Stock insufficient message received: {}", responseBody);

                String updateUrl = "http://localhost:9191/prodcat/api/v1/update";
                Map<String, Object> updatePayload = new HashMap<>();
                updatePayload.put("id", id);
                updatePayload.put("stock", stock);

                restTemplate.put(updateUrl, updatePayload);
                return "Product existed but stock was low — updated to " + stock;
            }

            logger.error("HTTP Error: {}", e.getMessage());
            throw e; // trigger fallback if unhandled
        } catch (Exception ex) {
            logger.error("Unexpected error: {}", ex.getMessage(), ex);
            throw ex; // trigger fallback
        }

        // Final Step: Call Inventory Service
        try {
            String inventoryUrl = "http://localhost:9191/inventoryservice/api/inventory/create";
            Map<String, Object> request = new HashMap<>();
            request.put("id", id);
            request.put("stock", stock);

            logger.info("Calling inventory at {}", inventoryUrl);
            String inventoryResponse = restTemplate.postForObject(inventoryUrl, request, String.class);
            logger.info("Inventory response: {}", inventoryResponse);

            return inventoryResponse != null ? inventoryResponse : "Inventory check failed";
        } catch (Exception ex) {
            logger.error("Error reserving inventory: {}", ex.getMessage(), ex);
            return "Inventory reservation failed";
        }
    }



  /*  @CircuitBreaker(name = "prodcat", fallbackMethod = "fallbackProd")
    public String callProdService(String id,int stock) {
        String url = "http://localhost:9191/prodcat/api/v1/" + id+"/"+stock;
        logger.info("Product call back started: {}", url);
       //return restTemplate.getForObject(url, String.class);
       String productResponse = restTemplate.getForObject(url, String.class);


        // Optional: Validate response if needed
        if (productResponse == null || productResponse.contains("not found")) {
           // return "Product not found";

            String createUrl = "http://localhost:9191/prodcat/api/v1/create";
            Map<String, Object> createPayload = new HashMap<>();
            createPayload.put("id", id);
            createPayload.put("stock", stock); // default stock

            restTemplate.postForObject(createUrl, createPayload, String.class);
            return "Product not found, so created with stock "+stock;
        }



        // ✅ 2. Product exists — parse stock from response (assuming response is like "stock: 0")
        int currentStock = Integer.parseInt(productResponse.replaceAll("[^0-9]", ""));
        if (currentStock < stock) {
            // ✅ Stock insufficient — update to 5
            String updateUrl = "http://localhost:9191/prodcat/api/v1/update";
            Map<String, Object> updatePayload = new HashMap<>();
            updatePayload.put("id", id);
            updatePayload.put("stock", stock);

            restTemplate.put(updateUrl, updatePayload);
            return "Product existed but stock was low — stock updated to 5";
        }


        // ✅ Call Inventory Service now
        String inventoryUrl = "http://localhost:9191/inventoryservice/api/inventory/create";
        Map<String, Object> request = new HashMap<>();
        request.put("id", id);
        request.put("stock", stock);

        try {
            logger.info("inventoryUrl:", inventoryUrl);
            logger.info("request:", request.toString());
            String inventoryResponse = restTemplate.postForObject(inventoryUrl, request, String.class);
            logger.info("inventoryResponse",inventoryResponse);
            return inventoryResponse != null ? inventoryResponse : "Inventory check failed";
        } catch (Exception ex) {
            logger.error("Error reserving inventory: {}", ex.getMessage());
            return "Inventory reservation failed";
        }

    }*/

    public String fallbackProd(String id, int stock, Throwable t) {
        logger.error("Fallback triggered for prodid={},stock={}, reason={}", id, stock, t.getMessage());
        return "Product info temporarily unavailable";
    }

    private boolean isNumeric(String str) {
        return str != null && str.matches("\\d+");
    }

}