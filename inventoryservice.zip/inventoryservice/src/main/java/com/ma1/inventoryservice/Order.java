package com.ma1.inventoryservice;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@Builder
@Document(collection = "orders")
public class Order {

    @Id
    private String id;
    private String customerId;
    private String productId;
    private int quantity;
    private String status;

}
