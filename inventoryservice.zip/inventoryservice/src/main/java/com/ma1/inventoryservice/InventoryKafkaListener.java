package com.ma1.inventoryservice;
import org.springframework.kafka.annotation.KafkaListener;

public class InventoryKafkaListener {

    private final InventoryService service;
    public InventoryKafkaListener(InventoryService service) { this.service = service; }

    @KafkaListener(topics = "order-topic")
    public void listen(Order order) {
        service.updateInventory(order);
    }
}
