package com.ma1.inventoryservice;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class InventoryRequest {

    private String id;
    private int stock;


}
