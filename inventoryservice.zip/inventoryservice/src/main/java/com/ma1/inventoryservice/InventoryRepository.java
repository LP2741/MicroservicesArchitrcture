package com.ma1.inventoryservice;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.ma1.inventoryservice.Inventory;

// InventoryRepository.java
public interface InventoryRepository extends MongoRepository<Inventory, String> {
    //Inventory findByProductId(String id);
}