package com.ma1.inventoryservice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InventoryService {
    private static final Logger logger = LoggerFactory.getLogger(InventoryService.class);

    private final InventoryRepository repo;


    public InventoryService(InventoryRepository repo) {
        this.repo = repo;

    }
    /*kafka purpose written this- my bad has to check after 11th july*/
 /*   public void updateInventory(Order order) {
        repo.findById(order.getId()).ifPresent(item -> {
            item.setStock(item.getStock() - order.getQuantity());
            repo.save(item);
        });
    }*/
    /*kafka purpose written this- my bad has to check after 11th july*/


    public boolean reserveStock(String id, int stock) {
       // Inventory inventory = repo.findById(id);
        Inventory inventory = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventory not found"));
          logger.info("inventory.getStock()",inventory.getStock());
        if (inventory != null && inventory.getStock() >= stock) {
            inventory.setStock(inventory.getStock() - stock);
            repo.save(inventory);
            return true;
        }

        return false; // Not enough stock or product doesn't exist
    }



    public Inventory pay(Inventory payment) {
        return repo.save(payment);
    }
}
