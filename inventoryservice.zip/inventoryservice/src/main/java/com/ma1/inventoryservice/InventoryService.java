package com.ma1.inventoryservice;
import org.springframework.stereotype.Service;



@Service
public class InventoryService {

    private final InventoryRepository repo;
    public InventoryService(InventoryRepository repo) { this.repo = repo; }

    public void updateInventory(Order order) {
        repo.findByProductId(order.getProductId()).ifPresent(item -> {
            item.setStock(item.getStock() - order.getQuantity());
            repo.save(item);
        });
    }
}
