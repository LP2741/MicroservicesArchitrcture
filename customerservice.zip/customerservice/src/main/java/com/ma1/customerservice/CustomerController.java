package com.ma1.customerservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

    @Autowired
    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping("/create")
    public Customer create(@RequestBody Customer customer) {
        return customerService.create(customer);
    }

    @GetMapping("/all")
    public List<Customer> getAll() {

        return customerService.getAll();
    }

    @GetMapping("/{id}")
    public Customer getById(@PathVariable String id) {
        return customerService.getById(id);
    }


private static final String MOCK_USERNAME = "admin";
private static final String MOCK_PASSWORD = "password";

@PostMapping("/login")
public ResponseEntity<String> login(@RequestParam String username,
                                    @RequestParam String password,
                                    HttpServletResponse response) {

    if (Objects.equals(username, MOCK_USERNAME) && Objects.equals(password, MOCK_PASSWORD)) {
        Cookie authCookie = new Cookie("auth_token", "securetoken123");
        authCookie.setHttpOnly(true);
        authCookie.setPath("/");
        response.addCookie(authCookie);
        return ResponseEntity.ok("Login success!");
    }

    return ResponseEntity.status(401).body("Invalid credentials.");
}

@GetMapping("/validate")
public ResponseEntity<String> validateCookie(@CookieValue(value = "auth_token", required = false) String token) {
    if ("securetoken123".equals(token)) {
        return ResponseEntity.ok("Token valid.");
    }
    return ResponseEntity.status(401).body("Invalid or missing token.");
}


}
