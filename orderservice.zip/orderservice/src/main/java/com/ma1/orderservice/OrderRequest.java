package com.ma1.orderservice;

import java.math.BigDecimal;

    public record OrderRequest(
            Long orderNumber,
            String id,
            BigDecimal price,
            Integer quantity
    ) {
    }

