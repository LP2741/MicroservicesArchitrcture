package com.ma1.orderservice;

import lombok.Data;
import java.util.List;

@Data
public class OrderRequest {
    private String customerId;
   // private List<String> items;
    private List<OrderItem> items;
    private double totalAmount;
    private String status;
}

