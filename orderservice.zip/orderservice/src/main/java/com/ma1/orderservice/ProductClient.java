package com.ma1.orderservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "prodcat", url = "${product.service.url}")
public interface ProductClient {

   @GetMapping("/checkstock/{id}/{quantity}")
   boolean checkStock(@PathVariable String id, @PathVariable int quantity, @RequestHeader("Cookie") String cookieHeader);

    @PostMapping("/deductstock/{id}/{quantity}")
    void deductStock(@PathVariable String id, @PathVariable int quantity, @RequestHeader("Cookie") String cookieHeader);


}



