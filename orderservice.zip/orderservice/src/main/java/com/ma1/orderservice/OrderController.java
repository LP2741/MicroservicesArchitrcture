package com.ma1.orderservice;


import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;
import org.springframework.web.reactive.function.client.WebClient;


@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private final OrderService service;

    @Autowired
    private WebClient webClient;

    public OrderController(OrderService service) {
        this.service = service;
    }

    @PostMapping("/login-customer")
    public Mono<ResponseEntity<String>> loginThroughGateway(@RequestParam String username,
                                                            @RequestParam String password,
                                                            HttpServletResponse response) {
        return webClient.post()
                .uri("/login") // full path is http://localhost:8080/customer/login
                .bodyValue("username=" + username + "&password=" + password)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .exchangeToMono(clientResponse -> {
                    if (clientResponse.statusCode().is2xxSuccessful()) {
                        String cookieHeader = clientResponse.headers().asHttpHeaders().getFirst("Set-Cookie");
                        if (cookieHeader != null) {
                            String token = cookieHeader.split("=")[1].split(";")[0];
                            Cookie cookie = new Cookie("auth_token", token);
                            cookie.setHttpOnly(true);
                            cookie.setPath("/");
                            response.addCookie(cookie);
                        }
                        return clientResponse.bodyToMono(String.class)
                                .map(body -> ResponseEntity.ok("Login successful: " + body));
                    } else {
                        return Mono.just(ResponseEntity.status(401).body("Invalid login"));
                    }
                });
    }


    @PostMapping("/place")
    public Object  placeOrder(@RequestBody OrderRequest orderRequest,
                                                    @CookieValue(value = "auth_token", required = false) String token) {

        // ✅ Very basic auth check (this was done by filter too, optional here)
        if (!"securetoken123".equals(token)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        OrderResponse response = service.placeOrder(orderRequest.getItems(), orderRequest.getCustomerId(), token);
        return response;
    }

    @GetMapping("/{id}")
    public Order getById(@PathVariable String id) {
        return service.getById(id);
    }

}

