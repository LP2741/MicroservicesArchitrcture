package com.ma1.orderservice;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;


import java.util.List;
import com.ma1.orderservice.ProductClient;

@Service
public class OrderService {
    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    private OrderRepository orderRepo;
    private final KafkaTemplate<String, Order> kafka;
    private  ProductClient productClient;

    public OrderService( ProductClient productClient,OrderRepository orderRepo, KafkaTemplate<String, Order> kafka) {
        this.orderRepo = orderRepo;
        this.kafka = kafka;
        this.productClient=productClient;
    }

    public Order placeOrderKalka(Order order) {
        logger.info("Order service started with product quantity: {}", order.getQuantity());
        order.setStatus("CREATED");

        Order savedOrder = orderRepo.save(order);;// Blocking save
        kafka.send("order-topic", savedOrder);    // Send to Kafka

        return savedOrder;
    }


    public OrderResponse placeOrder(List<OrderItem> items, String customerId, String sessionToken) {
        // 1. Check stock for each item
        for (OrderItem item : items) {
            boolean inStock = productClient.checkStock(
                    item.getProductId(),
                    item.getQuantity(),
                    "SESSION=" + sessionToken
            );
            if (!inStock) {
                throw new RuntimeException("Product " + item.getProductId() + " is out of stock or insufficient.");
            }
        }

        // 2. Deduct stock
        for (OrderItem item : items) {
            productClient.deductStock(
                    item.getProductId(),
                    item.getQuantity(),
                    "SESSION=" + sessionToken
            );
        }

        // 3. Save order
      //  List<String> productIds = items.stream().map(OrderItem::getProductId).toList();
        List<OrderItem> orderedItems = items.stream()
                .map(item -> new OrderItem(item.getProductId(), item.getQuantity()))
                .collect(Collectors.toList());


        double totalAmount = items.stream()
                .mapToDouble(i -> i.getQuantity() * 100) // Replace 100 with actual price lookup
                .sum();

        Order order = Order.builder()
                .customerId(customerId)
                .items(orderedItems)
                .totalAmount(totalAmount)
                .status("PLACED")
                .build();
        Order savedOrder = orderRepo.save(order);

        // 5. Return response
        return OrderResponse.builder()
                .orderId(savedOrder.getId())
                .customerId(savedOrder.getCustomerId())
                .items(savedOrder.getItems())
                .totalAmount(savedOrder.getTotalAmount())
                .message("Order placed and stock deducted successfully")
                .build();

    }

    public Order getById(String id) {
        return orderRepo.findById(id).orElse(null);
    }
}
