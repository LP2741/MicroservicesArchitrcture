package com.ma1.orderservice;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Mono;

@Service
public class OrderService {
    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepo;
    private final KafkaTemplate<String, Order> kafka;
    public OrderService(OrderRepository orderRepo, KafkaTemplate<String, Order> kafka) {
        this.orderRepo = orderRepo;
        this.kafka = kafka;
    }

    public Order placeOrder(Order order) {
        logger.info("Order service started with product quantity: {}", order.getQuantity());
        order.setStatus("CREATED");

        Order savedOrder = orderRepo.save(order); // Blocking save
        kafka.send("order-topic", savedOrder);    // Send to Kafka

        return savedOrder;
    }

}
