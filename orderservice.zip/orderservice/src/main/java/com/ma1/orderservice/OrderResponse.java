package com.ma1.orderservice;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class OrderResponse {

        private String orderId;
        private String customerId;
        private List<OrderItem> items;
        private double totalAmount;
        private String message;
        private int quantity;

}
