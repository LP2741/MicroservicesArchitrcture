package com.ma1.paymentservice;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

    @Service
    public class OrderClient {

        private static final Logger logger = LoggerFactory.getLogger(OrderClient.class);
        private final RestTemplate restTemplate;

        public OrderClient(RestTemplate restTemplate) {
            this.restTemplate = restTemplate;
        }

        @CircuitBreaker(name = "orderservice", fallbackMethod = "fallbackOrder")
        public String callOrderService(String orderId) {
            String url = "http://localhost:9191/orderservice/api/orders/" + orderId;
            logger.info("Calling Order Service: {}", url);
            return restTemplate.getForObject(url, String.class);
        }

        public String fallbackOrder(String orderId, Throwable t) {
            logger.error("Fallback triggered for orderId={}, reason={}", orderId, t.getMessage());
            return "unavailable";
        }
    }


