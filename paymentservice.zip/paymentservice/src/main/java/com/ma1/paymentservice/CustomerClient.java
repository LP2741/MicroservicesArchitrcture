package com.ma1.paymentservice;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class CustomerClient {
    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);


    private final RestTemplate restTemplate;

    public CustomerClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @CircuitBreaker(name = "customerService", fallbackMethod = "fallbackCustomer")
    public String callCustomerService(String customerId) {
        String url = "http://localhost:9191/customerservice/api/customers/" + customerId;
        logger.info("Customer call back started:", url);
        return restTemplate.getForObject(url, String.class);
    }

    public String fallbackCustomer(String customerId, Throwable t) {
        logger.error("Fallback triggered for customerId={}, reason={}", customerId, t.getMessage());
        return "Customer info temporarily unavailable";
    }
}
