package com.ma1.paymentservice;

import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    private final PaymentService paymentService;
    private final CustomerClient customerClient;
    private final OrderClient orderClient;

    public PaymentController(OrderClient orderClient,CustomerClient customerClient, PaymentService paymentService) {
        this.paymentService = paymentService;
        this.customerClient = customerClient;
        this.orderClient = orderClient;
    }

    @PostMapping("/create")
    public Object create(@RequestBody Payment payment) {
        try {
            String customerResponse = customerClient.callCustomerService(payment.getCustomerId());
            String orderResponse = orderClient.callOrderService(payment.getOrderId());

            logger.warn("customerResponse: {}",customerResponse);
            if (customerResponse == null ||customerResponse.contains("not found") || customerResponse.contains("unavailable")) {
                logger.warn("Customer validation failed for id: {}", payment.getCustomerId());
                return "Payment failed: Invalid customer";
            }
            logger.warn("orderResponse: {}",orderResponse);
            if (orderResponse == null ||
                    orderResponse.contains("not found") ||
                    orderResponse.contains("unavailable")) {
                logger.warn("Order validation failed for id: {}", payment.getOrderId());
                return "Payment failed: Invalid order";
            }

            return paymentService.pay(payment);
        } catch (Exception ex) {
            logger.error("Payment creation failed", ex);
            return "Payment failed due to internal error: " +ex.getMessage();
        }
        //return paymentService.pay(payment);
    }

    @GetMapping("/all")
    public List<Payment> getAll() {
        return paymentService.getAll();
    }

    @GetMapping("/{id}")
    public Payment getById(@PathVariable String id) {
        return paymentService.getById(id);
    }


   @GetMapping("/customercheck/{id}")
    public String checkCustomer(@PathVariable String id) {
       logger.info("Customer call back started:", id);
       return customerClient.callCustomerService(id);
  }
}
