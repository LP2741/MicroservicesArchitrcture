package com.ma1.paymentservice;


import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "payments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Payment {

    @Id
    private String id;
    private String orderId;
    private String customerId;
    private String paymentMethod; // e.g., CARD, UPI, NETBANKING
    private double amount;
    private String status; // SUCCESS, FAILED, PENDING
}
